package br.com.wichstream.wichstream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WichstreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(WichstreamApplication.class, args);
	}

}
