package br.com.wichstream.wichstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WichstreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
